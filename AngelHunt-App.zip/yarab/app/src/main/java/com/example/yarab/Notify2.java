package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Notify2 extends AppCompatActivity {
    String username;
    String urladdress="http://10.0.2.2/notify2.php";
    String[] title;
    String[] company;


    String[] image;
    ListView listview ;
    BufferedInputStream is;
    String Line =null;
    String result =null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify2);
        listview =(ListView)findViewById(R.id.lview);
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        //   collectData();
        Intent t=getIntent();
        username=  t.getStringExtra("username");
        String user= username;
        new Notify(this).execute("Notify",user);
    }


    public class Notify extends AsyncTask<String,Void,String> {


        Context context;
        AlertDialog alertDialog;
        private String result;


        Notify(Context ctx ) {
            context = ctx;
        }

        @Override
        protected String doInBackground(String... params) {
            String type=params[0];
            String login_url="http://10.0.2.2/notify2.php";


            if(type.equals("Notify")){
                try {
                    String user_name =params[1];

                    URL url =new URL(login_url);
                    HttpURLConnection httpURLConnection =(HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter( new OutputStreamWriter(outputStream,"UTF-8"));
                    String post_data= URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8");
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream=httpURLConnection.getInputStream();
                    BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                    String result="";
                    String Line="";
                    while((Line = bufferedReader.readLine())!=null){
                        result+=Line;

                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog =new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Notification dialog");


        }

        @Override
        protected void onPostExecute(String result) {

            this.result=result;
/*


            String result=result;
            super.onPostExecute(result);
            Intent intent = new Intent(com.example.yarab.Notify.this,Notify1.class);
            Bundle extras = new Bundle();
            extras.putString("result",result1);
            intent.putExtras(extras);
            context.getApplicationContext().startActivity(intent);
*/
            collectData(result);
        }


    }


    private void collectData(String result) {



        try{
            JSONArray ja=new JSONArray(result);
            JSONObject jo=null;

            title=new String[ja.length()];
            company=new String[ja.length()];

            image=new String[ja.length()];
            for(int i=0; i<ja.length();i++){
                jo=ja.getJSONObject(i);
                title[i]=jo.getString("user");
                company[i]=jo.getString("company");
                image[i]=jo.getString("path");

            }
            Notification2ListView notification2ListView= new Notification2ListView(this,title,company,image);
            listview.setAdapter(notification2ListView);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
