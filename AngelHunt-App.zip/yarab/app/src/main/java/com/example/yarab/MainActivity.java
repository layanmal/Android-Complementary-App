package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText usr, pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usr=(EditText)findViewById(R.id.email);
        pass=(EditText)findViewById(R.id.password);
    }

    public void OnLogin(View view) {
        String user= usr.getText().toString();
        String password= pass.getText().toString();
        String type = "login";
        BackgroundWorker backgroudworker= new BackgroundWorker(this);
        backgroudworker.execute(type,user,password) ;
      Intent myintent=new Intent(this,Funclay.class);

        myintent.putExtra("username", user);
      startActivity(myintent);

    }
    public void OpenReg(View view){
        startActivity(new Intent(this,registration.class));


    }

}
