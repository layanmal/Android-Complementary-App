package com.example.yarab;


import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class show2 extends AppCompatActivity {
    String[] title;
    String[] company;
    String[] path;
    String[] country;
    String[] type;
    String[]date;
    String[]organizers;
    String[]sponsors;
    String[]goal;
    String[]about;
    String[]email;
    String[]telephone;
    String[]website;
    ListView listview;
    BufferedInputStream is;
    String Line = null;
    String result = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show2);
        listview =(ListView)findViewById(R.id.lview);
        Intent t=getIntent();
        String title= t.getStringExtra("title");
        String company= t.getStringExtra("company");
        String user= title;
        String password=company;
        System.out.println(user);
        System.out.println(password);
        new Show(this).execute("Show",user,password);

    }
    public class Show extends AsyncTask<String,Void,String> {
        Context context;
        AlertDialog alertDialog;
        private String result;


        Show(Context ctx ) {
            context = ctx;
        }

        @Override
        protected String doInBackground(String... params) {
            String type=params[0];
            String login_url="http://10.0.2.2/show2.php";


            if(type.equals("Show")){
                try {
                    String user_name =params[1];
                    String password=params[2];
                    URL url =new URL(login_url);
                    HttpURLConnection httpURLConnection =(HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter( new OutputStreamWriter(outputStream,"UTF-8"));
                    String post_data= URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")+"&" +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8") ;  bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream=httpURLConnection.getInputStream();
                    BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                    String result="";
                    String Line="";
                    while((Line = bufferedReader.readLine())!=null){
                        result+=Line;

                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog =new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Notification dialog");


        }

        @Override
        protected void onPostExecute(String result) {

            this.result=result;

            collectData(result);
        }


    }


    private void collectData(String result) {



        try {
            JSONArray ja = new JSONArray(result);
            JSONObject jo = null;
            company = new String[ja.length()];
            title = new String[ja.length()];
             type = new String[ja.length()];
            country = new String[ja.length()];
            about = new String[ja.length()];
           goal = new String[ja.length()];
            path = new String[ja.length()];
            date = new String[ja.length()];
            sponsors= new String[ja.length()];
            organizers = new String[ja.length()];
            website = new String[ja.length()];
            email = new String[ja.length()];
            telephone = new String[ja.length()];
            for (int i = 0; i < ja.length(); i++) {
                jo = ja.getJSONObject(i);
                company[i] = jo.getString("company");
                title[i] = jo.getString("title");
                type[i] = jo.getString("type");
                country[i] = jo.getString("country");
                path[i] = jo.getString("path");
                date[i] = jo.getString("date");
                goal[i] = jo.getString("goal");
                about[i] = jo.getString("about");
                sponsors[i] = jo.getString("sponsors");
                organizers[i] = jo.getString("organizers");
                website[i] = jo.getString("website");
                email[i] = jo.getString("email");
                telephone[i] = jo.getString("telephone");

            }
            showListView jobListView = new showListView(this,title,company,type,country,about,goal,date,sponsors,organizers,website,email,telephone,path);
            listview.setAdapter(jobListView);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
