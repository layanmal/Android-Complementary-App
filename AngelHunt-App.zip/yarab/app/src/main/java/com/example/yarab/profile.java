package com.example.yarab;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.CollationElementIterator;

public class profile extends ArrayAdapter<String> {
    private String[] name;
    private String[] email;
    private String[] location;
    private String[] count;
    private String[] bio;
    private String[] path;
    private Activity context;
    private Bitmap bitmap;




    public profile(Activity context,String[] name, String[] email, String[] location, String[] bio, String[] count, String[] path) {
        super(context, R.layout.profile22,name);
        this.context=context;
        this.name=name;
        this.email=email;
        this.location=location;
        this.bio=bio;
        this.path=path;
        this.count=count;

    }

    @Nullable
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View r=convertView;
        profile.ViewHolder viewHolder=null;
        if(r==null){
            LayoutInflater layoutInflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            r=layoutInflater.inflate(R.layout.profile22,null,true);
            viewHolder =new profile.ViewHolder(r);
            r.setTag(viewHolder);
        }
        else{
            viewHolder =(profile.ViewHolder)r.getTag();
        }

        viewHolder.tvw1.setText(name[position]);
        viewHolder.tvw2.setText(email[position]);
        viewHolder.tvw3.setText(location[position]);
        viewHolder.tvw4.setText(bio[position]);
        viewHolder.tvw5.setText(count[position]);


        new profile.GetImageViewFromURL(viewHolder.ivw).execute(path[position]);
        return r;
    }
    class ViewHolder{
        TextView tvw3;
        TextView tvw1;
        TextView tvw2;
        TextView tvw4;
        TextView tvw5;

        ImageView ivw;
        ViewHolder(View v) {
            tvw1 = (TextView) v.findViewById(R.id.name);
            tvw2 = (TextView) v.findViewById(R.id.email);
            tvw3 = (TextView) v.findViewById(R.id.location);
            tvw4 = (TextView) v.findViewById(R.id.bio);
            tvw5 = (TextView) v.findViewById(R.id.count);
          //  tvw6 = (TextView) v.findViewById(R.id.email);
            ivw = (ImageView) v.findViewById(R.id.img);


        }
    }
    public class GetImageViewFromURL extends AsyncTask<String,Void, Bitmap> {
        ImageView img;
        public GetImageViewFromURL(ImageView imgv){
            this.img=imgv;

        }
        @Override
        protected Bitmap doInBackground(String... url) {
            String urldisplay=url[0];
            bitmap=null;

            try{
                URL urlConnection = new URL(urldisplay);
                HttpURLConnection connection = (HttpURLConnection) urlConnection
                        .openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                bitmap = BitmapFactory.decodeStream(input);


            }
            catch(Exception ex){
                ex.printStackTrace();
            }
            return bitmap;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap){
            super.onPostExecute(bitmap);
            img.setImageBitmap(bitmap);
        }
    }


}
