package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class registration extends AppCompatActivity {
    EditText firstname,lastname,email,password,confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        firstname=(EditText)findViewById(R.id.et_fname);

        lastname=(EditText)findViewById(R.id.et_lname);

        email=(EditText)findViewById(R.id.et_email);

        password=(EditText)findViewById(R.id.et_pass);

        confirm=(EditText)findViewById(R.id.et_conf);
    }

    public void OnReg(View view) {
        String str_name= firstname.getText().toString();
        String str_last= lastname.getText().toString();
        String str_email= email.getText().toString();
        String str_pass= password.getText().toString();
        String str_conf= confirm.getText().toString();
        String type = "Register";
        BackgroundWorker backgroudworker= new BackgroundWorker(this);
        backgroudworker.execute(type,str_name,str_last,str_email,str_pass,str_conf) ;
    }
}
