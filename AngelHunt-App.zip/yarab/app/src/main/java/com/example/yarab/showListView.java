package com.example.yarab;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class showListView extends ArrayAdapter<String> {
    private String[] company;
    private String[] title;

    private String[] country;
    private String[] path;
    private String[] date;
    private String[] type;
    private String[] organizers;
    private String[] sponsors;
    private String[] goal;
    private String[] about;
    private String[] email;
    private String[] telephone;
    private String[] website;
    private Activity context;
    private Bitmap bitmap;



    public showListView(Activity context, String[] title, String[] company, String[] type, String[] country,  String[] about,  String[] goal,  String[] date,  String[] sponsors,String[] organizers,String[] website,String[] email,String[] telephone,String[] path) {
        super(context, R.layout.show1,title);
        this.context=context;
        this.title=title;
        this.type =type;
        this.company= company;
        this.country = country;
        this.path = path;
        this.date=date;
        this.organizers=organizers;
        this.sponsors=sponsors;
        this.goal=goal;
        this.about=about;
        this.email=email;
        this.website=website;
        this.telephone=telephone;
    }


    @Nullable
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View r=convertView;
        showListView.ViewHolder viewHolder=null;
        if(r==null){
            LayoutInflater layoutInflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            r=layoutInflater.inflate(R.layout.show1,null,true);
            viewHolder =new showListView.ViewHolder(r);
            r.setTag(viewHolder);
        }
        else{
            viewHolder =(showListView.ViewHolder)r.getTag();
        }

        viewHolder.tvw1.setText(company[position]);
        viewHolder.tvw2.setText(title[position]);
        viewHolder.tvw6.setText(type[position]);
        viewHolder.tvw7.setText(country[position]);
        viewHolder.tvw8.setText(date[position]);
        viewHolder.tvw9.setText(about[position]);
        viewHolder.tvw10.setText(goal[position]);
       // viewHolder.tvw11.setText(sponsors[position]);
       // viewHolder.tvw12.setText(organizers[position]);
        viewHolder.tvw13.setText(website[position]);
        viewHolder.tvw14.setText(email[position]);
        viewHolder.tvw15.setText(telephone[position]);
        new showListView.GetImageViewFromURL(viewHolder.ivw).execute(path[position]);
        return r;
    }
    class ViewHolder{
        TextView tvw1;
        TextView tvw2;
        TextView tvw6;
        TextView tvw7;
        TextView tvw8;
        TextView tvw9;
        TextView tvw10;
       // TextView tvw11;
        //TextView tvw12;
        TextView tvw13;
        TextView tvw14;
        TextView tvw15;
        ImageView ivw;
        ViewHolder(View v) {
            tvw1 = (TextView) v.findViewById(R.id.title);
            tvw2 = (TextView) v.findViewById(R.id.tvprofilename2);

            tvw6 = (TextView) v.findViewById(R.id.job);
            tvw7 = (TextView) v.findViewById(R.id.country);
            tvw8 = (TextView) v.findViewById(R.id.publishedAt);
            tvw9 = (TextView) v.findViewById(R.id.about);
            tvw10 = (TextView) v.findViewById(R.id.goal);
            tvw13 = (TextView) v.findViewById(R.id.website);
            tvw14 = (TextView) v.findViewById(R.id.email);
            tvw15 = (TextView) v.findViewById(R.id.Telephone);
            ivw = (ImageView) v.findViewById(R.id.img2);

        }
    }
    public class GetImageViewFromURL extends AsyncTask<String,Void, Bitmap> {
        ImageView img;
        public GetImageViewFromURL(ImageView imgv){
            this.img=imgv;

        }
        @Override
        protected Bitmap doInBackground(String... url) {
            String urldisplay=url[0];
            bitmap=null;

            try{
                URL urlConnection = new URL(urldisplay);
                HttpURLConnection connection = (HttpURLConnection) urlConnection
                        .openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                bitmap = BitmapFactory.decodeStream(input);


            }
            catch(Exception ex){
                ex.printStackTrace();
            }
            return bitmap;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap){
            super.onPostExecute(bitmap);
            img.setImageBitmap(bitmap);
        }
    }


}
