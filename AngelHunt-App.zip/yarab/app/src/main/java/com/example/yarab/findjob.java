package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.GestureDetector;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class findjob extends AppCompatActivity {


        String urladdress = "http://10.0.2.2/findjob.php";
        String[] title;
        String[] company;
        String[] path;

        String[] country;
        String[] job;
        ListView listview;
        BufferedInputStream is;
        String Line = null;
        String result = null;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_findjob);
            listview = (ListView) findViewById(R.id.lview2);
            StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
            collectData();
listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView tvprofilename2 = (TextView) view.findViewById(R.id.tvprofilename2);
        String title1= title.getText().toString();
        String  tvprofilename = tvprofilename2 .getText().toString();

        Intent myintent=new Intent(getBaseContext(),single.class);

        myintent.putExtra("title", title1);
        myintent.putExtra("tvprofilename", tvprofilename);
        startActivity(myintent);
    }
});
        }

        private void collectData() {
            try {
                URL url = new URL(urladdress);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                is = new BufferedInputStream(con.getInputStream());
            } catch (Exception ex) {

                ex.printStackTrace();
            }


            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();

                while ((Line = br.readLine()) != null) {
                    sb.append(Line + "\n");
                }
                is.close();
                result = sb.toString();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
                JSONArray ja = new JSONArray(result);
                JSONObject jo = null;
                company = new String[ja.length()];
                title = new String[ja.length()];
                job = new String[ja.length()];
                country = new String[ja.length()];
                path = new String[ja.length()];
                for (int i = 0; i < ja.length(); i++) {
                    jo = ja.getJSONObject(i);
                    company[i] = jo.getString("company");
                    title[i] = jo.getString("title");
                    job[i] = jo.getString("job");
                    country[i] = jo.getString("country");
                    path[i] = jo.getString("path");


                }
                JobListView jobListView = new JobListView(this, company,title,job,country,path);
                listview.setAdapter(jobListView);

            } catch (Exception e) {
                e.printStackTrace();
            }

            }

    }
