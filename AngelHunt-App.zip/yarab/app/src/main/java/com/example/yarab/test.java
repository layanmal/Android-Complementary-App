package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class test extends AppCompatActivity {
    String urladdress="http://10.0.2.2/fetch.php";
    String[] title;
    String[] company;
    String[] type;
    String[] country;
    String[] date;
    String[] image;


    ListView listview ;
    BufferedInputStream is;
    String Line=null;
    String result=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        listview =(ListView)findViewById(R.id.lview);
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
collectData();
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView title = (TextView) view.findViewById(R.id.title);
                TextView company = (TextView) view.findViewById(R.id.company);
                String title1= title.getText().toString();
                String  company1 = company .getText().toString();

                Intent myintent=new Intent(getBaseContext(),show2.class);

                myintent.putExtra("title", title1);
                myintent.putExtra("company", company1);
                startActivity(myintent);
            }
        });
    }




    private void collectData() {
        try{
            URL url=new URL(urladdress);
            HttpURLConnection con=(HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is=new BufferedInputStream(con.getInputStream());
        }
            catch(Exception ex){

                ex.printStackTrace();
        }


        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(is));
            StringBuilder sb=new StringBuilder();

            while((Line=br.readLine())!=null){
                sb.append(Line+"\n");
            }
            is.close();
            result=sb.toString();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        try{
            JSONArray ja=new JSONArray(result);
            JSONObject jo=null;

            title=new String[ja.length()];
            company=new String[ja.length()];
            type=new String[ja.length()];
            country=new String[ja.length()];
            date=new String[ja.length()];
            image=new String[ja.length()];
            for(int i=0; i<ja.length();i++){
                jo=ja.getJSONObject(i);
                title[i]=jo.getString("title");
                company[i]=jo.getString("company");
                type[i]=jo.getString("type");
                country[i]=jo.getString("country");
                date[i]=jo.getString("date");
                image[i]=jo.getString("path");

            }
            CustomListView customListView= new CustomListView(this,title,company,type,country,date,image);
            listview.setAdapter(customListView);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        }

}
