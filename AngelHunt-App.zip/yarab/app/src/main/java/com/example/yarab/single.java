package com.example.yarab;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class single extends AppCompatActivity {
    String[] title;
    String[] company;
    String[] path;
    String[] country;
    String[] job;
    String[]date;
    String[]description;
    String[]req;
    ListView listview;
    BufferedInputStream is;
    String Line = null;
    String result = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single);
        listview =(ListView)findViewById(R.id.lview);
        Intent t=getIntent();
        String title= t.getStringExtra("title");
        String tvprofilename= t.getStringExtra("tvprofilename");
        String user= title;
        String password=tvprofilename;
        System.out.println(user);
        System.out.println(password);
        new Show(this).execute("Show",user,password);





    }

    public class Show extends AsyncTask<String,Void,String> {
        Context context;
        AlertDialog alertDialog;
        private String result;


        Show(Context ctx ) {
            context = ctx;
        }

        @Override
        protected String doInBackground(String... params) {
            String type=params[0];
            String login_url="http://10.0.2.2/show1.php";


            if(type.equals("Show")){
                try {
                    String user_name =params[1];
                    String password=params[2];
                    URL url =new URL(login_url);
                    HttpURLConnection httpURLConnection =(HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter( new OutputStreamWriter(outputStream,"UTF-8"));
                    String post_data= URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")+"&" +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8") ;  bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream=httpURLConnection.getInputStream();
                    BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                    String result="";
                    String Line="";
                    while((Line = bufferedReader.readLine())!=null){
                        result+=Line;

                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog =new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Notification dialog");


        }

        @Override
        protected void onPostExecute(String result) {

            this.result=result;

            collectData(result);
        }


    }


    private void collectData(String result) {



        try {
            JSONArray ja = new JSONArray(result);
            JSONObject jo = null;
            company = new String[ja.length()];
            title = new String[ja.length()];
            job = new String[ja.length()];
            country = new String[ja.length()];
            path = new String[ja.length()];
            date = new String[ja.length()];
            description = new String[ja.length()];
            req = new String[ja.length()];
            for (int i = 0; i < ja.length(); i++) {
                jo = ja.getJSONObject(i);
                company[i] = jo.getString("company");
                title[i] = jo.getString("title");
                job[i] = jo.getString("job");
                country[i] = jo.getString("country");
                path[i] = jo.getString("path");
                date[i] = jo.getString("date");
                description[i] = jo.getString("description");
                req[i] = jo.getString("req");

            }
            singleListView jobListView = new singleListView(this, company,title,job,country,path,date,description,req);
            listview.setAdapter(jobListView);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
