package com.example.yarab;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Funclay extends AppCompatActivity {
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funclay);

    }

    public void openNotify(View view) {
        Intent t=getIntent();
      username=  t.getStringExtra("username");
        String user= username;

        Intent myintent=new Intent(this, Notify1.class);
        myintent.putExtra("username",user.toString());
        startActivity(myintent);
    }

    public void OnProfile(View view) {
        Intent t=getIntent();
        username=  t.getStringExtra("username");
        String user= username;
        Intent myintent=new Intent(this, profile1.class);
        myintent.putExtra("username",user.toString());
        startActivity(myintent);
    }

    public void OnAnnounce(View view) {
        Intent myintent=new Intent(this,test.class);
        startActivity(myintent);

    }

    public void OnJobs(View view) {
        Intent myintent=new Intent(this, findjob.class);
        startActivity(myintent);
    }

    public void openNotify2(View view) {
        Intent t=getIntent();
        username=  t.getStringExtra("username");
        String user= username;

        Intent myintent=new Intent(this, Notify2.class);
        myintent.putExtra("username",user.toString());
        startActivity(myintent);
    }
}
